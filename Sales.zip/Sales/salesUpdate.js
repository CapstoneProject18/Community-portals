
//-----------------------------------------------------------------------------FUNCTION cropChange() STARTS---------------------------------------------------------------------------

function cropChange() {
	
	var crop1 = document.getElementById("crop").options[1].selected;
	var crop2 = document.getElementById("crop").options[2].selected;
	var crop3 = document.getElementById("crop").options[3].selected;
	var crop4 = document.getElementById("crop").options[4].selected;
	var crop5 = document.getElementById("crop").options[5].selected;
	var crop6 = document.getElementById("crop").options[6].selected;
	var crop7 = document.getElementById("crop").options[7].selected;
	var crop8 = document.getElementById("crop").options[8].selected;
	var crop9 = document.getElementById("crop").options[9].selected;
	var crop10 = document.getElementById("crop").options[10].selected;
	
	if(crop1 == true) {
	
		document.getElementById("variety").options[1].selected = "true";
		document.getElementById("variety").options[1].style.display = "block";
		document.getElementById("variety").options[2].style.display = "block";
		document.getElementById("variety").options[3].style.display = "block";
		document.getElementById("variety").options[4].style.display = "block";
		document.getElementById("variety").options[5].style.display = "block";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop2 == true) {
	
		document.getElementById("variety").options[6].selected = "true";
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "block";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop3 == true) {
	
		document.getElementById("variety").options[7].selected = "true";
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "block";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop4 == true) {
	
		document.getElementById("variety").options[8].selected = "true";
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "block";
		document.getElementById("variety").options[9].style.display = "block";
		document.getElementById("variety").options[10].style.display = "block";
		document.getElementById("variety").options[11].style.display = "block";
		document.getElementById("variety").options[12].style.display = "block";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop5 == true) {
		
		document.getElementById("variety").options[13].selected = "true";
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "block";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop6 == true) {
	
		document.getElementById("variety").options[14].selected = "true";
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "block";
		document.getElementById("variety").options[15].style.display = "block";
		document.getElementById("variety").options[16].style.display = "block";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop7 == true) {
	
		document.getElementById("variety").options[17].selected = "true";
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "block";
		document.getElementById("variety").options[18].style.display = "block";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop8 == true) {
	
		document.getElementById("variety").options[19].selected = "true";
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "block";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop9 == true) {
	
		document.getElementById("variety").options[20].selected = "true";
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "block";
		document.getElementById("variety").options[21].style.display = "block";
		document.getElementById("variety").options[22].style.display = "block";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop10 == true) {
	
		document.getElementById("variety").options[23].selected = "true";
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "block";
	
	}
	
}

//----------------------------------------------------------------------------FUNCTION cropChange() ENDS------------------------------------------------------------------------------

//----------------------------------------------------------------------------FUNCTION cropChange1() STARTS---------------------------------------------------------------------------

function cropChange1(crop) {
		
	if(crop == 'Banana') {
	
		document.getElementById("variety").options[1].style.display = "block";
		document.getElementById("variety").options[2].style.display = "block";
		document.getElementById("variety").options[3].style.display = "block";
		document.getElementById("variety").options[4].style.display = "block";
		document.getElementById("variety").options[5].style.display = "block";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop == 'Pomegranate') {
	
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "block";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop == 'Lime') {
	
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "block";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop == 'Cordyline') {
	
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "block";
		document.getElementById("variety").options[9].style.display = "block";
		document.getElementById("variety").options[10].style.display = "block";
		document.getElementById("variety").options[11].style.display = "block";
		document.getElementById("variety").options[12].style.display = "block";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop == 'Variegated Alpinia') {
		
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "block";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop == 'Lily') {
	
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "block";
		document.getElementById("variety").options[15].style.display = "block";
		document.getElementById("variety").options[16].style.display = "block";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop == 'Dioneae') {
	
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "block";
		document.getElementById("variety").options[18].style.display = "block";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop == 'Nepenthus') {
	
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "block";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop == 'Saraceniae') {
	
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "block";
		document.getElementById("variety").options[21].style.display = "block";
		document.getElementById("variety").options[22].style.display = "block";
		document.getElementById("variety").options[23].style.display = "none";
	
	} else if(crop == 'Phormium') {
	
		document.getElementById("variety").options[1].style.display = "none";
		document.getElementById("variety").options[2].style.display = "none";
		document.getElementById("variety").options[3].style.display = "none";
		document.getElementById("variety").options[4].style.display = "none";
		document.getElementById("variety").options[5].style.display = "none";
		document.getElementById("variety").options[6].style.display = "none";
		document.getElementById("variety").options[7].style.display = "none";
		document.getElementById("variety").options[8].style.display = "none";
		document.getElementById("variety").options[9].style.display = "none";
		document.getElementById("variety").options[10].style.display = "none";
		document.getElementById("variety").options[11].style.display = "none";
		document.getElementById("variety").options[12].style.display = "none";
		document.getElementById("variety").options[13].style.display = "none";
		document.getElementById("variety").options[14].style.display = "none";
		document.getElementById("variety").options[15].style.display = "none";
		document.getElementById("variety").options[16].style.display = "none";
		document.getElementById("variety").options[17].style.display = "none";
		document.getElementById("variety").options[18].style.display = "none";
		document.getElementById("variety").options[19].style.display = "none";
		document.getElementById("variety").options[20].style.display = "none";
		document.getElementById("variety").options[21].style.display = "none";
		document.getElementById("variety").options[22].style.display = "none";
		document.getElementById("variety").options[23].style.display = "block";
	
	}
	
}

//----------------------------------------------------------------------------FUNCTION cropChange1() ENDS------------------------------------------------------------------------------

//----------------------------------------------------------------------------FUNCTION rowNumber(x) STARTS----------------------------------------------------------------------------

function rowNumber(x) {
	
	var rowNo = x.rowIndex;
	
	var noOfColumns = document.getElementById("salesTable").rows[0].cells.length
	
	for(var i = 0; i < noOfColumns; i++) {
		
		var cellData = document.getElementById("salesTable").rows[rowNo].cells[i].innerHTML;

		var inputs = document.getElementsByClassName("input");
		
		var crop = cellData;
		
		cropChange1(crop);
		
		if(i == 1) {
		
			const [day, month, year] = cellData.split("-");
			cellData = year+'-'+month+'-'+day;
			
		}
		
		inputs[i].value = cellData;
		
	}
		
}

//---------------------------------------------------------------------------FUNCTION rowNumber(x) ENDS-------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------



function autoFill(x) {
	
	var amountTotal;
	
	if(x == 'qty') {
		
		var a = parseInt(document.getElementById(x).value);
		var b = parseFloat(document.getElementById("rateperunit").value);
		
		amountTotal = (isNaN(b) ? '' : parseFloat(a*b));
		amountTotal = (isNaN(a) ? '' : parseFloat(a*b));
	
	}
	
	if(x == 'rateperunit') {
		
		var b = parseFloat(document.getElementById(x).value);
		var a = parseInt(document.getElementById("qty").value);
		
		amountTotal = (isNaN(a) ? '' : parseFloat(a*b));
		amountTotal = (isNaN(b) ? '' : parseFloat(a*b));
		
	}
	
	document.getElementById('totalamount').value = amountTotal;
		
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

function formValidation() {
	
	var a = document.getElementById("qty").value;
	var b = document.getElementById("rateperunit").value;
	
	if(a == '') {
		
		document.getElementById("qty").style.borderColor = "red";
		document.getElementById("qty").style.borderWidth = "2px";
		document.getElementById("rateperunit").style.borderColor = "grey";
		document.getElementById("rateperunit").style.borderWidth = "1px";
		
		return false;
		
	}else if(b == '') {
		
		document.getElementById("rateperunit").style.borderColor = "red";
		document.getElementById("rateperunit").style.borderWidth = "2px";
		document.getElementById("qty").style.borderColor = "grey";
		document.getElementById("qty").style.borderWidth = "1px";
		
		return false;
		
	}else {
		
		return true;
		
	}
	
}

//------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------