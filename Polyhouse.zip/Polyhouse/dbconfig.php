<?php

	$link = mysqli_connect("localhost", "root", "", "shaili_biotech");
	
	if(mysqli_connect_error()) {
		
		die("<p>There was an error connecting</p>");
		
	}
	
?>
